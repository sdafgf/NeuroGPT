import { BuiltinMask } from "./typing";

export const CN_MASKS: BuiltinMask[] = [
  
];
